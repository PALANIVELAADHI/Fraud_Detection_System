import numpy as np
import matplotlib.pyplot as plt
import io
import base64
from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from config import templates

router = APIRouter()

# Assuming models, scaler, nn_model are loaded elsewhere (e.g., lazily as discussed)
models = None
scaler = None
nn_model = None

def load_models():
    global models, scaler, nn_model
    if models is None:
        import pickle
        import joblib
        import tensorflow as tf
        with open("models.pkl", "rb") as f:
            models = pickle.load(f)
        scaler = joblib.load("scaler.pkl")
        nn_model = tf.keras.models.load_model("model.h5")
    return models, scaler, nn_model

@router.get("/home", response_class=HTMLResponse)
async def home(request: Request):
    if "user" not in request.session:
        return RedirectResponse(url="/login", status_code=303)
    return templates.TemplateResponse("auth/home.html", {
        "request": request,
        "user": request.session.get("user")
    })

@router.post("/predict/", response_class=HTMLResponse)
async def predict(
    request: Request,
    amount: float = Form(...),
    customer_age: int = Form(...),
    transaction_hour: int = Form(...),
    device_risk_score: float = Form(...),
    location_distance: float = Form(...),
    num_transactions_last_24h: int = Form(...),
    avg_amount_last_7d: float = Form(...),
    is_new_device: int = Form(...),
    is_foreign_ip: int = Form(...)
):
    # Load models if not already loaded
    models, scaler, nn_model = load_models()

    # Prepare input data
    input_data = np.array([[amount, customer_age, transaction_hour, device_risk_score,
                            location_distance, num_transactions_last_24h, avg_amount_last_7d,
                            is_new_device, is_foreign_ip]])
    scaled_data = scaler.transform(input_data)
    prediction = models["random_forest"].predict_proba(scaled_data)[0][1]  # Probability of fraud

    # Generate plot
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(["Not Fraud", "Fraud"], [1 - prediction, prediction], color=['green', 'red'])
    ax.set_ylim(0, 1)
    ax.set_ylabel("Probability")
    ax.set_title("Fraud Detection Prediction")
    plt.tight_layout()

    # Save plot to buffer
    buf = io.BytesIO()
    plt.savefig(buf, format="png")
    buf.seek(0)
    plot_data = base64.b64encode(buf.getvalue()).decode("utf-8")
    plt.close(fig)  # Close the figure to free memory

    # Return template with prediction and plot
    return templates.TemplateResponse("auth/home.html", {
        "request": request,
        "user": request.session.get("user"),
        "prediction": f"{prediction:.2%}",
        "plot": f"data:image/png;base64,{plot_data}"  # Embed plot as base64
    })