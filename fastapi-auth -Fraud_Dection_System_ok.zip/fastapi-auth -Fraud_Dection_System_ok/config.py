from fastapi.templating import Jinja2Templates

# Centralized Templates
templates = Jinja2Templates(directory="templates")