import pandas as pd
import numpy as np
import pickle
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# Module 1 ---Data collection and Descriptionn
# Load dataset
df = pd.read_csv("transactions.csv")


# Module 2 ---Preprocessing and Encoding and scalling the 

# 2.1.Preprocessing

# 2.2.Slicing the data for X and Y Axis
X = df.drop(columns=["transaction_id", "timestamp", "is_fraud"])  # Drop non-numeric and target columns
y = df["is_fraud"]

# 2.3.Encode categorical columns  if categoric---string 
X = pd.get_dummies(X, drop_first=True)

# 2.4. Train-test split 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 2.5 Scale data....size...reduce ....100000...6 bit...100000/100---100..---access 100*100...1000000
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)


# Module 3 Trining ...3 alorithm ...

# 3.1...Methodologies

# Train models
models = {
    "logistic_regression": LogisticRegression(),
    "decision_tree": DecisionTreeClassifier(),
    "random_forest": RandomForestClassifier(n_estimators=100)
}

for name, model in models.items():
    model.fit(X_train, y_train)    # training...fit()....learning process..of ur model....
    
    
# Module 4 save model and preprocessing model AND Enhanced model ... alorithm ...

# Save models------main....
with open("models.pkl", "wb") as f:    # pickle file....
    pickle.dump(models, f)

# Save scaler.....preprocessing model file
joblib.dump(scaler, "scaler.pkl")  # write ur model file to ur hard disk...



# Fine tune process

# Save deep learning model
nn_model = Sequential([
    Dense(32, activation="relu", input_shape=(X_train.shape[1],)),
    Dense(16, activation="relu"),
    Dense(1, activation="sigmoid")
])
nn_model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])


nn_model.fit(X_train, y_train, epochs=10, batch_size=32, verbose=1)   

# fit()....
nn_model.save("model.h5")  #.....

print("Training complete, models saved.")
