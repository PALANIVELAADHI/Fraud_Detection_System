from fastapi import APIRouter, Form, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from db import SessionLocal
from models import User
import bcrypt
from config import templates  # Import from config.py

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/login")
async def login_page(request: Request):
    return templates.TemplateResponse("auth/login.html", {"request": request})

@router.post("/login")
async def login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.username == username).first()
    if user and bcrypt.checkpw(password.encode(), user.password.encode()):
        request.session['user'] = username
        return RedirectResponse(url="/home", status_code=303)
    return RedirectResponse(url="/login", status_code=303)

@router.post("/register")
async def register(
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    hashed_pw = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode()
    user = User(username=username, password=hashed_pw)
    db.add(user)
    db.commit()
    return RedirectResponse(url="/login", status_code=303)

@router.get("/logout")
@router.post("/logout")
async def logout(request: Request):
    print("Logout triggered")
    request.session.clear()
    return RedirectResponse(url="/login", status_code=303)