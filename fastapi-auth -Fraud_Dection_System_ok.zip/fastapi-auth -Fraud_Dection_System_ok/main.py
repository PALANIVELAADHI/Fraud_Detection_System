from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from fastapi.responses import RedirectResponse
from auth import router as auth_router
from model import router as model_router
from config import templates  # Import from config.py

app = FastAPI()

# Session Middleware
app.add_middleware(SessionMiddleware, secret_key="your_strong_secret_key_12345", session_cookie="session_id")

# Mount Static Files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Include Routers
app.include_router(auth_router)
app.include_router(model_router)

@app.get("/")
async def root(request: Request):
    return templates.TemplateResponse("auth/login.html", {"request": request})

@app.get("/register")
async def register_page(request: Request):
    return templates.TemplateResponse("auth/register.html", {"request": request})

@app.get("/home")
async def home(request: Request):
    if "user" not in request.session:
        return RedirectResponse(url="/login", status_code=303)
    return templates.TemplateResponse("auth/index.html", {"request": request})

